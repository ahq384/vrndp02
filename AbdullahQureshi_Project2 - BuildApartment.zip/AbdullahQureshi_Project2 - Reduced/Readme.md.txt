vrndp02

Virtual Reality Project 02 Google VR SDK V1.3
Unity Ver 5.6.1f1

Summary: Tried creating the required level of lighting and animation after several issues. Added a texture to the wall for additional aesthetics. I had to remove the Art folder under Asset as it was too big and therefore could not upload it to Github. 